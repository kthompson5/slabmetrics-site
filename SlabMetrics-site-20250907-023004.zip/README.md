# Slab Metrics (MVP) — Black/Green/White

Static site scaffold using HTML + Tailwind CDN. Designed for Netlify/Vercel/Render static hosting.